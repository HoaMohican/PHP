<?php
session_start();
include_once("models/Model.php");

class AdminController
{

    public $model;

    public function __construct()
    {
        $this->model = new Model();
    }

    //đăng nhập
    public function dangNhap() {
        include_once "views/admin/login/index.php";
        if(isset($_POST["username"])) {
            $user = $this->model->kiemTraDangNhap($_POST["username"],$_POST["password"]);
            if($user->num_rows > 0) {
                $user = $user->fetch_assoc();
                $_SESSION["display_name"] = $user["display_name"];
                header('Location: ?role=admin&page=dienthoai');
            }
            else echo "<script>alert('Tài khoản hoặc mật khẩu không chính xác.')</script>";
        }
    }

    public function dangXuat() {
        session_destroy();
        header('Location: ?role=admin&page=dangnhap');
    }

    // điện thoại
    public function quanLyDienThoai()
    {
        $dienthoai = $this->model->layDienThoai();
        $data = [];
        while($row = $dienthoai->fetch_assoc()) {
            $loai = $this->model->layLoaiId($row["hang"])->fetch_assoc();
            $row["tenhang"] = $loai["ten"];
            array_push($data,$row);
        }
        include_once "views/admin/dienthoai/index.php";
    }
    public function themDienThoai() {
        $loai = $this->model->layLoai();
        if(isset($_POST["ten"])) {
            $ha_sp = '';
            if (isset($_FILES['anh'])) {

                if ($_FILES['anh']['error'] > 0)
                {
                    echo 'Upload ảnh lỗi.';
                }
                else {
                    move_uploaded_file($_FILES['anh']['tmp_name'], './views/assets/image/'.$_FILES['anh']['name']);
                    $ha_sp = "./views/assets/image/".$_FILES['anh']['name'];
                    if($this->model->themDT($_POST["ten"],$_POST["hang"],$_POST["mota"],$_POST["daciemnoibat"],$_POST["gia"],$ha_sp,$_POST["sl"])) {
                        header('Location: ?role=admin&page=dienthoai');
                    }
                    else echo 'Thêm thất bại';
                }
            }

        }
        include_once "views/admin/dienthoai/them.php";
    }
    public function suaDienThoai() {
        $loai = $this->model->layLoai();
        $id = $_GET["id_sua"];
        if(!isset($_POST["ten"])) $dienthoai = $this->model->layDienThoaiId($id)->fetch_assoc();
        else {
            $ha_sp = $_POST["anh_cu"];
            if (isset($_FILES['anh'])) {
                if ($_FILES['anh']['error'] > 0)
                {
                    echo 'Upload ảnh lỗi.';
                }
                else {
                    move_uploaded_file($_FILES['anh']['tmp_name'], './views/assets/image/'.$_FILES['anh']['name']);
                    $ha_sp = "./views/assets/image/".$_FILES['anh']['name'];
                }
            }

            if($this->model->suaDT($id,$_POST["ten"],$_POST["hang"],$_POST["mota"],$_POST["daciemnoibat"],$_POST["gia"],$ha_sp  , $_POST["sl"])) {
                header('Location: ?role=admin&page=dienthoai');
            }
            else echo 'Sửa thất bại';
        }
        include_once "views/admin/dienthoai/sua.php";
    }
    public function xoaDienThoai()
    {
        $id=$_GET["id_xoa"];
        if($this->model->xoaDT($id)) {
            header('Location: ?role=admin&page=dienthoai');
        }
        else echo 'Xóa thất bại';
    }

    // loại điện thoại
    public function quanLyLoai()
    {
        $loai = $this->model->layLoai();
        include_once "views/admin/loai/index.php";
    }
    public function themLoai() {
        if(isset($_POST["ten"])) {
            if($this->model->themL($_POST["ten"],$_POST["mota"])) {
                header('Location: ?role=admin&page=loai');
            }
            else echo 'Thêm thất bại';
        }
        include_once "views/admin/loai/them.php";
    }
    public function suaLoai() {
        $id = $_GET["id_sua"];
        if(!isset($_POST["ten"])) $loai = $this->model->layLoaiId($id)->fetch_assoc();
        else {
            if($this->model->suaL($id,$_POST["ten"],$_POST["mota"])) {
                header('Location: ?role=admin&page=loai');
            }
            else echo 'Sửa thất bại';
        }
        include_once "views/admin/loai/sua.php";
    }
    public function xoaLoai()
    {
        $id=$_GET["id_xoa"];
        if($this->model->xoaL($id)) {
            header('Location: ?role=admin&page=loai');
        }
        else echo 'Xóa thất bại';
    }

    // hóa đơn
    public function quanLyHoaDon()
    {
        $hoadon = $this->model->layHoaDon();
        include_once "views/admin/hoadon/index.php";
    }
    public function duyetHoaDon() {
        $id = $_GET["id"];
        $hoadon = $this->model->layHoaDonId($id)->fetch_assoc();
        if(isset($_POST["trangthai"])) {
            if($this->model->duyetHD($id,$_POST["trangthai"])) {
                if($_POST["trangthai"] == 3) {
                    $chitiethoadon = $this->model->layChiTietHoaDon($id);
                    if($chitiethoadon->num_rows > 0) {
                        while ($row = $chitiethoadon->fetch_assoc()) {
                            $this->model->giamSoLuong($row["id_sp"],$row["soluong"]);
                        }
                    }
                }
                header("Location: ?role=admin&page=hoadon");
            }
            else echo "Duyệt thất bại";
        }
        include_once "views/admin/hoadon/duyet.php";
    }
    public function xoaHoaDon()
    {
        $id=$_GET["id_xoa"];
        if($this->model->xoaHD($id)) {
            header('Location: ?role=admin&page=hoadon');
        }
        else echo 'Xóa thất bại';
    }
    public function chiTietHoaDon() {
        $id = $_GET["id"];
        $chitiet = $this->model->chiTietHD($id);
        $data = [];
        while($row = $chitiet->fetch_assoc()) {
            $loai = $this->model->layLoaiId($row["hang"])->fetch_assoc();
            $row["tenhang"] = $loai["ten"];
            array_push($data,$row);
        }
        include_once "views/admin/hoadon/chitiet.php";
    }

    // bình luận
    public function quanLyBinhLuan()
    {
        $binhluan = $this->model->layBinhLuan();
        include_once "views/admin/binhluan/index.php";
    }
    public function duyetBinhLuan() {
        $id = $_GET["id"];
        $trangThai = 1;
        $binhluan = $this->model->layBinhLuanId($id)->fetch_assoc();
        if($binhluan["trangthai"] == 1) $trangThai = 0;
        if($this->model->duyetBL($id,$trangThai)) {
            header("Location: ?role=admin&page=binhluan");
        }
        else echo "Duyệt thất bại";
    }
    public function xoaBinhLuan()
    {
        $id=$_GET["id_xoa"];
        if($this->model->xoaBL($id)) {
            header('Location: ?role=admin&page=binhluan');
        }
        else echo 'Xóa thất bại';
    }
    public function thongke()
    {
        $ketqua=$this->model->thongkedulieu();
        include_once "views/admin/thongke/index.php";

    }

    public function tonKho() {
        $dienthoai = $this->model->layDienThoai();
        $data = [];
        while($row = $dienthoai->fetch_assoc()) {
            $loai = $this->model->layLoaiId($row["hang"])->fetch_assoc();
            $row["tenhang"] = $loai["ten"];
            array_push($data,$row);
        }
        include_once "views/admin/tonkho/index.php";
    }

    public function muaNhieu() {
        $dienthoai = $this->model->thongKeMuaNhieu();
        $data = [];
        while($row = $dienthoai->fetch_assoc()) {
            $loai = $this->model->layLoaiId($row["hang"])->fetch_assoc();
            $row["tenhang"] = $loai["ten"];
            array_push($data,$row);
        }
        include_once "views/admin/muanhieu/index.php";
    }

}