<?php


class Model
{
    public $conn;
    public function __construct()
    {
        $this->conn = new mysqli("localhost","u287647950_bhdt","02032002Hoa@@","u287647950_bhdt")  or die("Ket noi that bai");
        $this->conn->set_charset("UTF8");
    }
    
    public function kiemTraDangNhap($username,$password) {
        $sql = "select * from user where username = '$username' and password = '$password'";
        $result = $this->conn->query($sql);
        return $result;
    }

    // admin
    public function layDienThoai() {
        $sql = "select * from dienthoai";
        $result = $this->conn->query($sql);
        return $result;
    }
    public function layDienThoaiId($id) {
        $sql = "select * from dienthoai where id = $id";
        $result = $this->conn->query($sql);
        return $result;
    }
    public function themDT($ten, $hang, $mota, $daciemnoibat, $gia,$anh,$sl)
    {
        $sql= "insert into dienthoai( ten, hang,mota, daciemnoibat, gia, anhminhhoa,sl) values( '$ten', $hang, '$mota','$daciemnoibat', $gia, '$anh','$sl')";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function suaDT($id, $ten,$hang,$mota,$daciemnoibat,$gia,$anh,$sl)
    {
        $sql="update dienthoai set ten='$ten', hang=$hang, mota='$mota', daciemnoibat='$daciemnoibat', gia=$gia, anhminhhoa='$anh' , sl=$sl where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function xoaDT($id)
    {
        $sql="delete from dienthoai where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }

    //loai diện thoại
    public function layLoai() {
        $sql = "select * from loai";
        $result = $this->conn->query($sql);
        return $result;
    }
    public function layLoaiId($id) {
        $sql = "select * from loai where id = $id";
        $result = $this->conn->query($sql);
        return $result;
    }
    public function themL($ten, $mota)
    {
        $sql= "insert into loai(ten,mota) values('$ten','$mota')";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function suaL($id, $ten,$mota)
    {
        $sql="update loai set ten='$ten', mota = '$mota' where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function xoaL($id)
    {
        $sql="delete from loai where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }

    // hóa đơn
    public function layHoaDon() {
        $sql = "select hoadon.*, khachhang.ten,khachhang.diachi,khachhang.sdt from hoadon inner join khachhang on khachhang.id = hoadon.khachhang_id";
        $result = $this->conn->query($sql);
        return $result;
    }
    public function layHoaDonId($id) {
        $sql = "select hoadon.*, khachhang.ten,khachhang.diachi,khachhang.sdt from hoadon inner join khachhang on khachhang.id = hoadon.khachhang_id where hoadon.id = $id";
        $result = $this->conn->query($sql);
        return $result;
    }

    public function layChiTietHoaDon($id) {
        $sql = "select * from chitiethoadon where id_hd = $id";
        $result = $this->conn->query($sql);
        return $result;
    }


    public function duyetHD($id, $trangthai)
    {
        $sql="update hoadon set trangthai=$trangthai where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function xoaHD($id)
    {
        $sql="delete from hoadon where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function chiTietHD($id) {
        $sql="select * from chitiethoadon inner join dienthoai on chitiethoadon.id_sp = dienthoai.id join hoadon on chitiethoadon.id_hd = hoadon.id join khachhang on hoadon.khachhang_id = khachhang.id where id_hd = $id";
        $result= $this->conn->query($sql);
        return $result;
    }

    // bình luận
    public function layBinhLuan() {
        $sql="select binhluan.*,dienthoai.ten from binhluan inner join dienthoai on binhluan.id_sp = dienthoai.id";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function layBinhLuanId($id) {
        $sql="select * from binhluan where id = $id";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function duyetBL($id,$trangthai) {
        $sql="update binhluan set trangthai=$trangthai where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }
    public function xoaBL($id)
    {
        $sql="delete from binhluan where id=$id";
        $result= $this->conn->query($sql);
        return $result;
    }

    // user
    public function TK($search) {
        $sql ="select * from dienthoai where ten like '%$search%'";
        $result = $this->conn->query($sql);
        return $result;
    }

    public function BL($id, $ten, $noidung) {
        $sql= "insert into binhluan(id_sp,noidung,hoten,trangthai) values($id,'$noidung','$ten',0)";
        $result= $this->conn->query($sql);
        return $result;
    }

    public function layBinhLuanCT($id) {
        $sql = "select * from binhluan where id_sp = $id and trangthai = 1";
        $result = $this->conn->query($sql);
        return $result;
    }

    public function taoHoaDon($hoten,$diachi,$sdt,$ghichu,$tongtien) {
        $sql = "select * from khachhang where sdt = '$sdt'";
        $result = $this->conn->query($sql);
        $khachhang_id = 0;
        if($result->num_rows > 0) {
            $khachhang_id = $result->fetch_assoc()["id"];
        }
        else {
            $sql = "insert into khachhang(ten,diachi,sdt) values('$hoten','$diachi','$sdt')";
            $this->conn->query($sql);
            $khachhang_id = $this->conn->insert_id;
        }
        $sql = "insert into hoadon(khachhang_id,ghichu,tongtien,trangthai) values($khachhang_id,'$ghichu',$tongtien,0)";
        $result = $this->conn->query($sql);
        if($result) {
            $idHoaDon = $this->conn->insert_id;
            foreach ($_SESSION["giohang"] as $item) {
                if($this->ktraHoaDon($item["id"],$item["soluong"]))
                {
                    $idSp = $item["id"];
                    $gia = $item["gia"];
                    $soluong = $item["soluong"];
                    $sql= "insert into chitiethoadon(id_sp,id_hd,gia,soluong) values($idSp,$idHoaDon,$gia,$soluong)";
                    $this->conn->query($sql);

                }
                else
                {
                    return false;
                }

            }
        }
        return true;
    }
    public function ktraHoaDon($id, $sl)
    {
        $sql= "select * from dienthoai where id=$id";
        $result= $this->conn->query($sql)->fetch_assoc();
        if($result["sl"]<$sl)
            return false;
        return true;
    }
    public function thongkedulieu()
    {
        $sql="select * from hoadon where trangthai=3  ";
        $result= $this->conn->query($sql);
        $doanhthu= 0;
        while($dong=$result->fetch_assoc())
        {
            $doanhthu= $doanhthu + $dong["tongtien"];
        }
        $sql="select * from dienthoai ";
        $result= $this->conn->query($sql);
        $tongdienthoai= $result->num_rows;

        $sql="select * from khachhang ";
        $result=$this->conn->query($sql);
        $tongkhachhang=$result->num_rows;

        $data["doanhthu"]= $doanhthu;
        $data["tongdienthoai"]= $tongdienthoai;
        $data["tongkhachhang"]= $tongkhachhang;
        return $data;
    }

    public function giamSoLuong($id_sp, $soluong) {
        $sql = "update dienthoai set sl = sl - $soluong where id = $id_sp";
        $result = $this->conn->query($sql);
        return $result;
    }

    public function thongKeMuaNhieu() {
        $sql = "select dienthoai.*, count(id_sp) as sp_count from dienthoai left join chitiethoadon on dienthoai.id = chitiethoadon.id_sp group by dienthoai.id order by sp_count desc";
        $result = $this->conn->query($sql);
        return $result;
    }
}