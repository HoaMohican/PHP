<div class="header">
    <h2>QUẢN LÍ BÁN HÀNG ĐIỆN THOẠI DI ĐỘNG</h2>
    <div class="user-info">
        Xin chào, <?php echo $_SESSION["display_name"]?>
        <a href="?role=admin&page=dangxuat"><i class="fa fa-sign-out"></i></a>
    </div>
</div>