<div class="sidebar">
    <ul>
        <li name="dienthoai"><a href="?role=admin&page=dienthoai"><i class="fa fa-mobile"></i>Quản lý điện thoại</a></li>
        <li name="loai"><a href="?role=admin&page=loai"><i class="fa fa-bars"></i>Quản lý loại</a></li>
        <li name="hoadon"><a href="?role=admin&page=hoadon"><i class="fa fa-money"></i>Quản lý hóa đơn</a></li>
        <li name="binhluan"><a href="?role=admin&page=binhluan"><i class="fa fa-comment"></i>Quản lý bình luận</a></li>
        <li name="thongke"><a href="?role=admin&page=thongke"><i class="fa fa-line-chart"></i>Thống kê</a></li>
        <li name="tonkho"><a href="?role=admin&page=tonkho"><i class="fa fa-archive"></i>Tồn kho</a></li>
        <li name="muanhieu"><a href="?role=admin&page=muanhieu"><i class="fa fa-star-o"></i>Điện thoại mua nhiều</a></li>
    </ul>
</div>