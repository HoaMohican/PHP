$(function () {
    $(".sidebar li[name="+$("body").attr("name")+"]").addClass("active");
})