$(function () {
    $('.owl-carousel').owlCarousel({
        items: 1,
        height: 300,
        loop: true,
        autoplay: true,
        autoplayTimeout:3000,
        autoplayHoverPause:true
    })
})