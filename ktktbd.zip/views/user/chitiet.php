<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $dienthoai["ten"]; ?></title>
    <link rel="stylesheet" href="./views/assets/css/home.css">
    <link rel="stylesheet" href="./views/assets/font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="./views/assets/OwlCarousel2-2.3.4/dist/assets/owl.carousel.css">
    <script src="./views/assets/js/jquery-3.5.1.min.js"></script>
    <script src="./views/assets/OwlCarousel2-2.3.4/dist/owl.carousel.js"></script>
    <script src="./views/assets/js/home.js"></script>
</head>
<body>
<div class="wrapper">

    <?php include_once "./views/user/header.php"?>

    <div class="content">
        <div class="chitiet-info">
            <div class="chitiet-tieude">
                <?php echo $dienthoai["ten"]; ?>
            </div>
            <div class="chitiet-mota">
                <div class="chitiet-img">
                    <div class="ct-image">
                        <img src="<?php echo $dienthoai["anhminhhoa"]; ?>" alt="">
                    </div>
                    <div class="chitiet-gia">
                        <div>
                            <div class="ct-gia">
                                <p >Giá</p>
                                <p style="color:red;"><?php echo $dienthoai["gia"]; ?><span style="font-size:20px;">₫</span></p>
                            </div>
                        </div>
                        <div class="ct-giaohang">
                            <i class="fa fa-clock-o"></i>
                            <span>GIAO HÀNG TRONG 1 GIÒ 63 TỈNH THÀNH</span>
                        </div>
                        <div class="ct-kmdacbiet">
                            <p>Khuyến mãi đặc biệt</p>
                            <div>
                                <ul>
                                    <li>Trả góp 0%, trả trước chỉ 469,000đ </li>
                                    <li>Tặng suất mua Đồng hồ thời trang giảm đến 40% </li>
                                    <li>Mua gói bảo hành chính hãng mở rộng 24 tháng giá 269,000đ.  </li>
                                </ul>
                            </div>
                        </div>
                        <div class="ct-muangay">
                            <a href="?role=user&action=themgiohang&loai=muangay&id=<?php echo $dienthoai["id"];  ?>"><button>MUA NGAY</button></a>
                            <a href="?role=user&action=themgiohang&loai=themvaogio&id=<?php echo $dienthoai["id"];  ?>"><button class="btn-themvaogio">THÊM VÀO GIỎ</button></a>
                        </div>
                    </div>
                </div>
                <div class="chitiet-hop">
                    <p>Trong hộp có</p>
                    <div>
                        <i class="fa fa-archive"></i>
                        <span>Máy, Sạc, Cáp, Sách hướng dẫn, cây lấy sim</span>
                    </div>
                    <p>THTShop cam kết</p>
                    <ul class="menu-camket">
                        <li><i class="fa fa-star"></i> Hàng chính hãng</li>
                        <li><i class="fa fa-shield"></i> Bảo hành 12 Tháng chính hãng</li>
                        <li><i class="fa fa-truck"></i> Giao hàng miễn phí toàn quốc trong 60 phút</li>
                        <li><i class="fa fa-map-marker"></i> Bảo hành nhanh tại THT Shop trên toàn quốc</li>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="chitiet-thongso">
            <div class="dacdiem">
                <div class="dacdiem-tieude">Mô tả</div>
                <div class="dacdiem-nd">
                    <?php echo $dienthoai["mota"] ?>
                </div>
            </div>
            <div class="thongso">
                <div class="thongso-tieude">Thông số</div>
                <div class="thongso-nd">

                </div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="chitiet-binhluan">
            <div class="binhluan-tieude">Bình luận</div>
            <div class="binhluan-nd">
                <form action="?role=user&action=binhluan&id=<?php echo $dienthoai["id"]; ?>" method="post">
                    <input type="text" name="ten" placeholder="Họ tên" required>
                    <textarea name="noidung" rows="3" required placeholder="Nội dung"></textarea>
                    <div><button>Gửi bình luận</button></div>
                </form>
                <div class="binhluan-danhsach">
                    <?php
                        if($binhluan->num_rows > 0) while($dong = $binhluan->fetch_assoc()) {
                    ?>
                            <div class="binhluan-item">
                                <div class="binhluan-avatar">
                                    <?php
                                        echo substr($dong["hoten"],0,1);
                                    ?>
                                </div>
                                <div class="binhluan-content">
                                    <p class="bl-ten"><b><?php echo $dong["hoten"]; ?></b><span class="bl-ngay"><?php echo $dong["ngay"]; ?></span></p>
                                    <p class="bl-content"><?php echo $dong["noidung"]; ?></p>
                                </div>
                            </div>
                    <?php } ?>

                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <div>
            <div class="f-item">
                <ul>
                    <li><a href="#">Giới thiệu về công ty</a></li>
                    <li><a href="#">Câu hỏi thường gặp mua hàng</a></li>
                    <li><a href="#">Chính sách bảo mật</a></li>
                    <li><a href="#">Quy chế hoạt động</a></li>
                    <li><a href="#">Kiểm tra hóa đơn điện tử</a></li>
                    <li><a href="#">Tra cứu thông tin bảo hành</a></li>
                </ul>
            </div>
            <div class="f-item">
                <ul>
                    <li><a href="#">Tin tuyển dụng</a></li>
                    <li><a href="#">Tin khuyến mãi</a></li>
                    <li><a href="#">Hướng dẫn mua online</a></li>
                    <li><a href="#">Hướng dẫn mua trả góp</a></li>
                    <li><a href="#">Chính sách trả góp</a></li>
                    <li><a href="#">Tra cứu thông tin bảo hành</a></li>
                </ul>
            </div>
            <div class="f-item">
                <ul>
                    <li><a href="#">Hệ thống cửa hàng</a></li>
                    <li><a href="#">Hệ thống bảo hành</a></li>
                    <li><a href="#">Kiểm tra hàng Apple chính hãng</a></li>
                    <li><a href="#">Giới thiệu máy đổi trả</a></li>
                    <li><a href="#">Chính sách đổi trả</a></li>
                </ul>
            </div>
            <div class="clear"></div>
        </div>

    </div>

</div>
</body>
</html>