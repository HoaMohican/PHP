<div class="menu">
    <ul>
        <li><a href=""><i class="fa fa-mobile"></i>ĐIỆN THOẠI</a></li>
        <li><a href=""><i class="fa fa-laptop"></i> LAPTOP</a></li>
        <li><a href=""><i class="fa fa-apple"></i>APPLE</a></li>
        <li><a href=""><i class="fa fa-clock-o"></i>ĐỒNG HỒ</a></li>
        <li><a href=""><i class="fa fa-headphones"></i>PHỤ KIỆN</a></li>
        <li><a href=""><i class="fa fa-refresh"></i>MÁY ĐỔI TRẢ</a></li>
        <li><a href=""><i class="fa fa-tablet"></i>TABLET</a></li>
    </ul>
</div>